/*
This is empty on purpose! Your code to build the resume will go here.
*/
var Myname = "Andres Mendoza"
var Myrole = "Web Developer"
var formattedName = HTMLheaderName.replace("%data%", Myname)
var formattedRole = HTMLheaderRole.replace("%data%", Myrole)
$("#header").append(formattedName);
$("#header").append(formattedRole);

var work ={
  "jobs":[
    {
      "employer": "AT&T",
      "title": "Prefessional RAN Engineer",
      "location": "Las Vegas, NV, US",
      "dates": "2016-Future",
      "description": "Do Stuff to make phones work good"
    },
    {
      "employer": "Cricket",
      "title": "Senior RF Engineer",
      "location": "Las Vegas, NV, US",
      "dates": "2008-2016",
      "description": "Do Stuff to make phones work good"
    }
  ]
}

var projects ={
  "projects": [
    {
      "title":"Project 1",
      "dates": "2014",
      "description": "This is the 1st project of the list",
      "images": ["images/skelove.jpg", "images/skelive.jpg", "images/skelaugh.jpg"]//project wants URL, but I'll put this in for now
    },
    {
      "title":"Project 2",
      "dates": "2015",
      "description": "This is the 2nd project of the list",
      "images": ["images/skelove.jpg", "images/skelive.jpg", "images/skelaugh.jpg"]//project wants URL, but I'll put this in for now
    }
  ]
}

var bio ={
    "name": "Andres Mendoza ",
    "role": "web developer ",
    "welcomeMessage": "Here is the Welcome Message.  I Hope this makes you feel Welcomed",
    "biopic": "images/fry.jpg",
    "contacts": {
      "mobile": "999-999-9999",
      "email": "this.contact@email.com",
      "github": "thisgithub",
      "twitter": "@Ihavenotwitter",
      "location": "Las Vegas, NV, US"
    },
    "skills": [
      "Make all putts within 1ft", "Grill edible steaks", "Drive to the Store"
    ]
};

var education = {
  "Schools":[
    {
      "name": "University of Nevada Las Vegas",
      "location": "Las Vegas, NV, US",
      "degree dates": "2000",
      "url": "https://www.unlv.edu",
      "majors": ["Electrical Engineer"]
    },
    {
      "name": "Community College of Southern Nevada",
      "location": "Las Vegas, NV, US",
      "degree dates": "2000",
      "url": "https://www.csn.edu",
      "majors": ["Electrical Engineer"]
    }
  ],
  "onlineCourses":[
    {
      "title": "Web Developer Nanodegree",
      "school": "Udacity",
      "dates": "On Going",
      "url": "https://www.Udacity.com"
    }
  ]
};

if (bio.length !== 0) {
  $("#header").append(HTMLskillsStart); //HTMLskillsStart is a variable set in helper.js
  var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]); //here we are applying the format to the 1st element in the skills array
  $("#skills").append(formattedSkill);//here we append the result to id=skills
  var formattedSkill = HTMLskills.replace("%data%", bio.skills[1]);
  $("#skills").append(formattedSkill);
  var formattedSkill = HTMLskills.replace("%data%", bio.skills[2]);
  $("#skills").append(formattedSkill);
};

function displayWork () {
for (job in work.jobs) {            //this gives us the jobs array in the work object.  job is the iterator
    $("#workExperience").append(HTMLworkStart);  //#workExperience is the div in the HTML
    var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs [job].employer); //creates a variable to store new formated employer we are replacing "%data%"
    var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs [job].title);//with the fields in the array we want to change the format to.
    var formattedDates = HTMLworkDates.replace("%data%", work.jobs [job].dates);//HTMLworkDates comes from helper.js (similarly all the other ones)
    var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs [job].description);
    var formattedLocation = HTMLworkLocation.replace("%data%", work.jobs [job].location);  //all of them worked except this one
    var formattedEmployerTitle = formattedEmployer + formattedTitle;  // this concatenates employer and title
    $(".work-entry:last").append(formattedEmployerTitle);//work-entry was given to us in the question.  .work-entry is a class
    $(".work-entry:last").append(formattedDates);//we can tell .work-entry is a class because how its formatted here.
    $(".work-entry:last").append(formattedDescription);
    $(".work-entry:last").append(formattedLocation);
  };
};
displayWork ();  //here we invoke our code to display the work information

function locationizer() { //this takes the work object from above
  var locationArray =[]; //this initializes a new array (empty for now)
  for (job in work.jobs) {  //this iterates through every job within work_obj.jobs.
      var newLocation = work.jobs[job].location; //for each job we'll create this variable, that gets overwritten
      locationArray.push(newLocation); //this pushes the new array value to teh array
  }
  return locationArray;
}
// Did locationizer() work? This line will tell you!
console.log(locationizer(work));

function inName(name) { //function takes parameter "name"
  name = name.trim().split(" ");//here we have it take space from the front and the back of the estring
  console.log (name);
  name[1] = name[1].toUpperCase();//this changes all 2nd name to uppercase
  name[0] = name[0].slice(0,1).toUpperCase() + name[0].slice(1).toLowerCase();
  return name[0] + " "+ name[1];
}
$("#main").append(internationalizeButton);

projects.displayproject = function () { //This is how to encapsulate a function call "displayproject"
  for (project in projects.projects) { //to the "projects" element
    $("#projects").append(HTMLprojectStart);
    var formattedProjectTitle = HTMLprojectTitle.replace("%data%",projects.projects [project].title);
    var formattedProjectDates = HTMLprojectDates.replace("%data%",projects.projects [project].dates);
    var formattedProjectDescription = HTMLprojectDescription.replace("%data%",projects.projects [project].description);
    $(".project-entry:last").append(formattedProjectTitle);
    $(".project-entry:last").append(formattedProjectDates);
    $(".project-entry:last").append(formattedProjectDescription);

    if (projects.projects [project].images.length > 0) { //This is similar to what was done in bio portion
      for (image in projects.projects [project].images) {
        var formattedImage = HTMLprojectImage.replace("%data%",projects.projects [project].images[image]);
        $(".project-entry:last").append(formattedImage);
      }
    }
  };
};

projects.displayproject (); //THIS IS HOW YOU INVOKE THE FUNCTION WHEN ENCAPSULATING IT EARLIER!!

$("#mapDiv").append(googleMap);
