/*
This is empty on purpose! Your code to build the resume will go here.
 */
// $("#main").append("Andres Mendoza");
//var AwesomeThoughts = "I am Andres and I am AWESOME!";
//var FunThoughts = AwesomeThoughts.replace("AWESOME", "FUN");
// $("#main").append(FunThoughts);  //this has to be placed after we defined the variable. Didnt work when I put it at the top of the code
//console.log(AwesomeThoughts);
//console.log(FunThoughts);
var name = "Andres Mendoza"
var role = "Web Developer"
var formattedName = HTMLheaderName.replace("%data%", name)
var formattedRole = HTMLheaderRole.replace("%data%", role)
$("#header").append(formattedName);
$("#header").append(formattedRole);
